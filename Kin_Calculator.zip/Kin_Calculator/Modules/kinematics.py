import math
import pylab as pl
import numpy as np
import utilities
import sys

def kin_calculator(thetacm,T1,initial_parameters):
	  m1 = initial_parameters[0]
	  m2 = initial_parameters[1]
	  m3 = initial_parameters[2]
	  m4 = initial_parameters[3]
	  Ex = initial_parameters[4]
	  Exr = initial_parameters[5]
	  Q = initial_parameters[6]
	  T2= 0.0
	  E1 = T1 + m1  #Total energy of particle 1 (kinetic + mass) in MeV
	  E2 = T2 + m2  #Total energy of particle 2 (kinetic + mass) in MeV
	  p1= math.sqrt( math.pow(T1,2) + 2*T1*m1) #Momentum of particle 1
	  p2= math.sqrt( math.pow(T2,2) + 2*T2*m2) #Momentum of particle 2
	  Ecm = math.sqrt ( math.pow(E1+E2,2) - math.pow(p1 + p2,2) ) #Total energy of the system in the center-of-mass
	  Ticm = Ecm - m1 -m2	 # Total kinetic energy before the reaction
	  Tfcm = Ticm + Q - Ex - Exr  # Available kinetic energy after the reaction
	  if (Tfcm <= 0.0):
		return 0
		quit()
	  #Relativistic factors for the system of two particles:
	  bsp = (p1 + p2)/(E1 +E2)            #Beta
	  gamma = math.sqrt ( 1./ (1.-math.pow(bsp,2))) #Gamma
 	  #---------------------------------------------------#
	  T3cm = (Tfcm/2.)*(Tfcm+2.*m4)/Ecm
	  T4cm = (Tfcm/2.)*(Tfcm+2.*m3)/Ecm
	  b3cm = math.sqrt (math.pow(T3cm,2) + 2.*T3cm*m3)/(T3cm + m3)
	  b4cm = math.sqrt (math.pow(T4cm,2) + 2.*T4cm*m4)/(T4cm + m4)
	  p3cm = math.sqrt ( T3cm*(T3cm + 2*m3))
	  p4cm = math.sqrt ( T4cm*(T4cm + 2*m4))

	  theta3cm = thetacm
	  theta4cm = math.pi - thetacm

	  theta3lab = math.atan(math.sin(theta3cm)/(gamma*(math.cos(theta3cm)+(bsp/b3cm))))  #angle theta3 in radians
	  theta4lab = math.atan(math.sin(theta4cm)/(gamma*(math.cos(theta4cm)+(bsp/b4cm))))  #angle theta4 in radians
	  theta3lab_deg = 57.295779513*math.atan(math.sin(theta3cm)/(gamma*(math.cos(theta3cm)+(bsp/b3cm))))  #angle theta3 in deg
	  theta4lab_deg = 57.295779513*math.atan(math.sin(theta4cm)/(gamma*(math.cos(theta4cm)+(bsp/b4cm))))  #angle theta4 in deg
	  T3 = (gamma - 1.)*m3 + gamma*T3cm + gamma*bsp*p3cm*math.cos(theta3cm)      #kinetic energy of prtcle 3 in MeV
	  T4 = (gamma - 1.)*m4 + gamma*T4cm + gamma*bsp*p4cm*math.cos(theta4cm)     #kinetic energy of prtcle 4 in MeV
	  theta3cm_deg = theta3cm*57.295779513  # angle theta3_cm in deg
	  theta4cm_deg = theta4cm*57.295779513  # angle theta4_cm in deg

	  Output1=[theta3cm,theta3lab,theta3lab_deg,T3,theta4cm,theta4lab,theta4lab_deg,T4,T3cm,T4cm]
       	  return Output1



def change_angle(theta,phi,InitialCosx,InitialCosy,InitialCosz):
	if (phi <= math.pi):
	   phi_neut = 57.295779513*(phi + math.pi)    #Neutron angle phi in degrees
           phi_neut_rad = phi + math.pi               #Neutron angle phi in radians
	else:
          phi_neut = 57.295779513*(phi - math.pi)
          phi_neut_rad = phi - math.pi

	cosx_r = math.cos(theta)
	cosy_r = math.sin(theta)*math.sin(phi)
	cosz_r = math.sin(theta)*math.cos(phi)
	thetay_r = math.acos(cosy_r)
	thetaz_r = math.acos(cosz_r)
	Az = math.acos(InitialCosz)
	px = (math.pow(math.acos(InitialCosx),2) - math.pow(math.acos(InitialCosy),2))/math.pi  +  math.pi/4.
	if (Az < math.pi/2.):
  	   py = math.sqrt ( math.fabs (math.pow(math.acos(InitialCosx),2) - math.pow(px,2))  )
	else:
	   py = - math.sqrt ( math.fabs (math.pow(math.acos(InitialCosx),2) - math.pow(px,2))  )
	thetaz =  thetaz_r - py
	thetay =  thetay_r + px

	FinalCosz = math.cos(thetaz)
	FinalCosy = math.cos(thetay)
	FinalCosx = math.sqrt( math.fabs (1. - math.pow(FinalCosz,2) - math.pow(FinalCosy,2) ))

	Output2 = [FinalCosx,FinalCosy,FinalCosz]
	return Output2
