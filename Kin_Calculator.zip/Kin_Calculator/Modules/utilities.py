import os, sys
import shutil
import re
import numpy as np
import datetime

sys.path.append(os.getcwd() + '/Modules/')



def create_output_file():
	if os.path.exists('OUTPUTS/Default'):
		x=raw_input('\nOverwrite files in "Default"? [y/n]\n')
		if not (x=='y' or x=='n'): x=raw_input('Overwrite files in "Default"?  Please type "y" or "n":\n')
		if not (x=='y' or x=='n'): x='n'
		if (x=='y'):
			shutil.rmtree('OUTPUTS/Default')
   			os.makedirs('OUTPUTS/Default')
			print "\n"
		if (x=='n' ):
			y=raw_input('\nCreate a new folder for your output files. Type name: \n')
			os.makedirs('OUTPUTS/{}'.format(y))
			print "\n"
	if not os.path.exists('OUTPUTS/Default'):
    		os.makedirs('OUTPUTS/Default')
	return 0





def read_srim_filename(Input_File):
	f = open(Input_File,'r')
	for line in f:
		if ("Input SRIM file:" in line): filename = line.split()[-1]
	f.close()
	return filename





def read_talys_filename(Input_File):
	f = open(Input_File,'r')
	for line in f:
		if ("Input Talys file" in line): filename = line.split()[-1]
	f.close()
	return filename




def check_input_options(Input_File):
	f = open(Input_File,'r')
	for line in f:
		if ("Create TRIM.dat from TRANSMIT file:" in line): O1 = line.split()[-1]
		if ("Create new TRIM.dat from scratch:" in line): O2 = line.split()[-1]
		if ("Uniform angular distribution:" in line): O3 = line.split()[-1]
		if ("Angular distribution from Talys:" in line): O4 = line.split()[-1]
		if ("Type of reaction" in line): O5 = line.split()[-1]
		if ("excited state (if Talys" in line): O6 = int(line.split()[-1])
		if ("Reaction mechanism" in line): O7 = line.split()[-1]
		if ("Number of Particles:" in line): O8 = int(line.split()[-1])
		if ("Projectile energy[MeV]:" in line): O9 = float(line.split()[-1])
		O10 = "empty"
		if ("Energy spread [%]" in line): O11 = float(line.split()[-1])
		if ("Uniform distribution:" in line): O12 = line.split()[-1]
		if ("Gaussian distribution:" in line): O13 = line.split()[-1]

	if (O1==O2):
		print "\n\n**WARNING**"
		print "The following lines were found in your input file:"
		print "'Create TRIM.dat from TRANSMIT file: {}'".format(O1)
		print "'Create TRIM.dat from scratch: {}'".format(O2)
		print "Please pick one of the two options!\n"
		exit()

	if (O3==O4):
		print "\n\n**WARNING**"
		print "The following lines were found in your input file:"
		print "'Uniform distribution: {}'".format(O3)
		print "'Angular distribution from Talys: {}'".format(O4)
		print "Please pick one of the two options!\n"
		exit()

	output=[O1,O2,O3,O4,O5,O6,O7,O8,O9,O10,O11,O12,O13]
	return output



def check_input_options_ToF(Input_File):
	f = open(Input_File,'r')
	for line in f:
		if ("Projectile energy[MeV]:" in line): O1 = float(line.split()[-1])
		if ("Energy spread [%]" in line): O2 = float(line.split()[-1])
		if ("Time-of-Flight length (m)" in line): O3 = float(line.split()[-1])
		if ("Number of excited states:" in line): O4 = line.split()[-1]
		if ("Recoil Excitation Energies (MeV):" in line): O5 = line.split()[-int(O4):]
	f.close()
	output=[O1,O2,O3,O4,O5]
	return output




def read_input_plot_options(Input_File):
	plots=[]
	f = open(Input_File,'r')
	for line in f:
		if ("Recoil energies:" in line): plots.append(line.split()[-1])
		if ("Ejectile energies:" in line): plots.append(line.split()[-1])
		if ("Recoil angles" in line): plots.append(line.split()[-1])
		if ("Ejectile angles" in line): plots.append(line.split()[-1])
		if ("Ejectiles angular" in line): plots.append(line.split()[-1])
		if ("Recoils angular" in line): plots.append(line.split()[-1])
	f.close()
	return plots




def read_input_parameters(Input_File):
	nuclei = []
	parameters=[]
	masses_amu = masses_mev = [0,0,0,0]
	Zp=Zt=Ze=Zr=0
	f = open(Input_File,'r')
	for line in f:
		if ("Projectile(M1):" in line): nuclei.append((line.split()[-1]))
		if ("Target(M2):" in line): nuclei.append((line.split()[-1]))
		if ("Ejectile(M3):" in line): nuclei.append((line.split()[-1]))
		if ("Recoil(M4):" in line): nuclei.append((line.split()[-1]))
		if ("Ejectile Excitation Energy" in line): parameters.append(float(line.split()[-1]))
		if ("Recoil Excitation Energy" in line): parameters.append(float(line.split()[-1]))
	f.close()

	if parameters==[]: parameters=[0.0,0.0] #If I do TOF calculation

	for n,i in enumerate(nuclei):
		if (i=='p' or i=='P'): nuclei[n]='1H'
		if (i=='d' or i=='D'): nuclei[n]='2H'
		if (i=='n' or i=='N'): nuclei[n]='1n'
		if (i=='a' or i=='A'): nuclei[n]='4He'
		if (i=='t' or i=='T'): nuclei[n]='3H'
		if (i=='g' or i=='gamma'): nuclei[n]='0g'

	projectile = re.split(r'(\d+)', nuclei[0])
	target = re.split(r'(\d+)', nuclei[1])
	ejectile = re.split(r'(\d+)', nuclei[2])
	recoil = re.split(r'(\d+)', nuclei[3])

	A = [projectile[1], target[1], ejectile[1], recoil[1]]
	symbols = [projectile[2], target[2], ejectile[2], recoil[2]]

	for n,i in enumerate(symbols):
		if not (i=='n' or i=='g'): symbols[n]=symbols[n][0].upper()+symbols[n][1:]

	f = open(os.getcwd() + '/Parameters/masses.dat','r')
	for line in f:
		if ("{}".format(" " + A[0] + " " +  symbols[0]) in line):
			masses_amu[0] = float(line.split()[-3]+line.split()[-2])
			if ( line.startswith(('0 ', '\t')) ): Zp = int(line.split()[3])
			elif ( line.startswith((' ', '\t')) ): Zp = int(line.split()[2])

		if ("{}".format(" " + A[1] + " " + symbols[1]) in line):
			masses_amu[1] = float(line.split()[-3]+line.split()[-2])
			if ( line.startswith(('0 ', '\t')) ): Zt = int(line.split()[3])
			elif ( line.startswith((' ', '\t')) ): Zt = int(line.split()[2])

		if ("{}".format(" " + A[2] + " " + symbols[2]) in line):
			masses_amu[2] = float(line.split()[-3]+line.split()[-2])
			if ( line.startswith(('0 ', '\t')) ): Ze = int(line.split()[3])
			elif ( line.startswith((' ', '\t')) ): Ze = int(line.split()[2])

		if ("{}".format(" " + A[3] + " " + symbols[3]) in line):
			masses_amu[3] = float(line.split()[-3]+line.split()[-2])
			if ( line.startswith(('0 ', '\t')) ): Zr = int(line.split()[3])
			elif ( line.startswith((' ', '\t')) ): Zr = int(line.split()[2])
	f.close()

	M1_tot=int(projectile[1])+int(target[1])
	M2_tot=int(ejectile[1])+int(recoil[1])
	if not (Zp+Zt == Ze+Zr and M1_tot==M2_tot ):
		sys.exit("\n CAUTION!  This reaction cannot happen: {} \n".format(nuclei[0]+"("+nuclei[1]+","+nuclei[2]+")"+nuclei[3]))

	masses_mev[0] = masses_amu[0]*931.49422E-6 - Zp*0.511
	masses_mev[1] = masses_amu[1]*931.49422*1E-6 - Zt*0.511
	masses_mev[2] = masses_amu[2]*931.49422*1E-6 - Ze*0.511
	masses_mev[3] = masses_amu[3]*931.49422*1E-6 - Zr*0.511

	Q = masses_mev[0] + masses_mev[1] - masses_mev[2] - masses_mev[3]
	out = [masses_mev[0],masses_mev[1],masses_mev[2],masses_mev[3],parameters[0],parameters[1], Q, Zp, Zt, Ze, Zr , nuclei[2],nuclei[3]]

	return out     #out = [ M1, M2, M3, M4, ExE, ExR, Q ]



def check_typos_input_file(Input_File):
	f = open(Input_File,'r')
	for line in f:
		if (":" in line):
			if not (": " in line): sys.exit("\n CAUTION!  Check your input file (leave spaces after ':') \n")
	f.close()
	return 0






def pdf_from_talys_file(filename,Level,reaction):
	FILE=[]
	textFile = open(filename,'r')
	for line in textFile:
		FILE.append(line)
	textFile.close()


	try:
	     Angular_distributions_In = filter(lambda x: 'Inelastic angular distributions' in x, FILE)
	     Angular_distributions_Ot = filter(lambda x: 'Angular distributions for other reactions' in x, FILE)

	except:
		print "No angular distributions were found in the file you provided!"
		exit()


	try:
	     A = filter(lambda x: '{} angular distributions'.format(reaction) in x, FILE)
	     LineA = FILE.index(A[0])
	except:
		print "No such a reaction"
		exit()


	LevelNo = [i for i,x in enumerate(FILE) if 'Level  {}'.format(Level) in x]
	Reactions = [i for i,x in enumerate(FILE) if ') angular distributions' in x]



	Reaction_Position = Reactions.index(LineA)
	if (Reaction_Position < len(Reactions)-1):
		Next_Reaction_Position = Reactions.index(LineA)+1
		Start = LineA
		End = Reactions[Next_Reaction_Position]

	else:
		Start = LineA
		End = len(FILE)-1

	Correct_Level=0
	for i in LevelNo:
		if (i>Start and i<End): Correct_Level=i
	if (Correct_Level==0):
		print "No such Level"
		exit()

	Angle,Total_CS,Direct_CS, Compound_CS, PDF_Tot, PDF_Dir,PDF_Comp= [],[],[],[],[],[],[]

	for i in xrange(Correct_Level+4,Correct_Level+95,1):
		Angle.append(FILE[i].split()[0])
		Total_CS.append(FILE[i].split()[1])
		Direct_CS.append(FILE[i].split()[2])
		Compound_CS.append(FILE[i].split()[3])

	Sum1=Sum2=Sum3=0.0
	for i in Total_CS:
		Sum1 += float(i)
		PDF_Tot.append(Sum1)

	for i in Direct_CS:
		Sum2 += float(i)
		PDF_Dir.append(Sum2)

	for i in Compound_CS:
		Sum3 += float(i)
		PDF_Comp.append(Sum3)

	output = [ PDF_Tot, PDF_Dir , PDF_Comp]

	return output




def read_srim_file(in_file):
	E = []
	X = []
	Y = []
	Z = []
	COSX = []
	COSY = []
	COSZ = []
	NumberOfParticles=0
	sys.stdout.write('Read SRIM file......')
	sys.stdout.flush()
	with open("SRIM_files/{}".format(in_file)) as textFile:
		for line in textFile:
			if line.startswith('T'):
				E.append(float(line[7:].split()[1]))
				X.append(float(line[7:].split()[2]))
				Y.append(float(line[7:].split()[3]))
				Z.append(float(line[7:].split()[4]))
				COSX.append(float(line[7:].split()[5]))
				COSY.append(float(line[7:].split()[6]))
				COSZ.append(float(line[7:].split()[7]))
				NumberOfParticles +=1

			elif line[0].isdigit():
				E.append(float(line.split()[2]))
				X.append(float(line.split()[3]))
				Y.append(float(line.split()[4]))
				Z.append(float(line.split()[5]))
				COSX.append(float(line.split()[6]))
				COSY.append(float(line.split()[7]))
				COSZ.append(float(line.split()[8]))
				NumberOfParticles +=1

	sys.stdout.write('  100.0 %')
	sys.stdout.write('\n')
	Eaverage = np.mean(E)*1E-6
	output = [E,X,Y,Z,COSX,COSY,COSZ,Eaverage,NumberOfParticles]

	return output


def get_number_from_pdf(PDF):
	Random = np.random.uniform(PDF[0],PDF[89])
	for i in PDF:
	   if (i>=Random) :
		Theta_cm_index=	PDF.index(i)
		break
	return Theta_cm_index



def get_number_from_pdf_2(PDF):
	Random = np.random.uniform(PDF[0],PDF[89])
	for i in PDF:
	   if (i>=Random) :
		Theta_cm_index=	PDF.index(i)
		break
	Theta_cm = float(2*Theta_cm_index)/57.2958
	return Theta_cm




def reset(array):
	array=0
	return array




def make_report(input_file,output_file,note):
	f1 = open("{}/Report.txt".format(output_file),'wb')
	f1.write("       *************************\n                REPORT       \n      *************************\n")
	f1.write("Date of excecution: {} \n\n".format(datetime.datetime.now().strftime("%Y/%m/%d - %H:%M:%S")))
	f1.write(note)
	f1.write("\n\n***** INPUT OPTIONS *****\n\n")
	f2 = open(input_file,'r')

	for line in f2:
		if (":" in line): f1.write(line)

	f1.close()
	f2.close()
	return 0
