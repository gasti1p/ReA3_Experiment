
import numpy as np
import math
import pylab as pl
import sys
import os
import glob
import time
sys.path.append(os.getcwd() + '/Modules/')
import kinematics
import utilities



input_file = sys.argv[-1]
utilities.check_typos_input_file(input_file)
input_options=utilities.check_input_options(input_file)
utilities.create_output_file()
output_file = max(glob.iglob('OUTPUTS/*'), key=os.path.getctime)
kinematics_parameters = utilities.read_input_parameters(input_file)


if (input_options[0]=='yes'):
	SRIM = utilities.read_srim_file(utilities.read_srim_filename(input_file))
	E = SRIM[0]			#Energy in eV (as given in SRIM file)
	X = SRIM[1]			#X-position in Angstrom (as given in SRIM file)
	Y = SRIM[2]			#Y-position in Angstrom (as given in SRIM file)
	Z = SRIM[3]			#Z-position in Angstrom (as given in SRIM file)
	COSX = SRIM[4]			#CosX (as given in SRIM file)
	COSY = SRIM[5]			#CosY (as given in SRIM file)
	COSZ = SRIM[6]			#CosZ (as given in SRIM file)
	Eaverage = SRIM[7]     		#Average energy in MeV
	NumberOfParticles=SRIM[8]

	if (kinematics.kin_calculator(0.0,Eaverage,kinematics_parameters)==0):
		sys.exit("\n**CAUTION: Not enough c.m. energy for this reaction!\n")
else:
	if (kinematics.kin_calculator(0.0,input_options[8],kinematics_parameters)==0):
		sys.exit("\n**CAUTION: Not enough c.m. energy for this reaction!\n")


NumberOfRejectedIons=0
W1=False
W2=False



if not (kinematics_parameters[12] == '1n' or kinematics_parameters[12] == '0g'):
	outR = open("{}/TRIM_Recoils.dat".format(output_file), 'wb')
else:
	outR = open("{}/junk_file".format(output_file), 'wb')
	W1=True

if not (kinematics_parameters[11] == '1n' or kinematics_parameters[11] == '0g'):
	outE = open("{}/TRIM_Ejectiles.dat".format(output_file), 'wb')
else:
	outE = open("{}/junk_file".format(output_file), 'wb')
	W2=True


for line in open('Parameters/TRIM_sample.dat', 'r'):
	outR.write(line)
	outE.write(line)


recoil_file = open("{}/Recoil_characteristics.txt".format(output_file), 'wb')
ejectile_file = open("{}/Ejectile_characteristics.txt".format(output_file), 'wb')
recoil_file.write(" IonNumber   Ecm(MeV)  Elab(MeV)   Theta_cm(deg)   Theta_lab(deg)   Theta_SRIM(deg)     Reac. E (MeV)    Px (rad)    Py (rad)\n")
ejectile_file.write(" IonNumber   Ecm(MeV)   Elab(MeV)   Theta_cm(deg)   Theta_lab(deg)   Theta_SRIM(deg)\n")


sys.stdout.write('Calculate new angles and energies......:   0 %')
sys.stdout.flush()


#========================================================================#
#              If Talys angular distributions are used:
#========================================================================#

if (input_options[3]=='yes'):
	talys_file = utilities.read_talys_filename(input_file)
	PDF = utilities.pdf_from_talys_file("TALYS_files/{}".format(talys_file),input_options[5],input_options[4])



#========================================================================#
#     		    Create new TRIM.dat from scratch
#========================================================================#


if (input_options[1]=='yes'):
	for l in xrange(0,input_options[7],1):
		progress=100*float(l)/float(input_options[7])
		sys.stdout.write('\rCalculate new angles and energies...... {} %'.format(round(progress,1)))


		Phi_cm = np.random.uniform(0,2*math.pi)


		if (input_options[2]=='yes'): 	#Uniform angular distribution
			Theta_cm = np.random.uniform(0,math.pi)


		if (input_options[3]=='yes'):   #Talys angular distribution
			if (input_options[6]=='Total'): Theta_cm=utilities.get_number_from_pdf_2(PDF[0])
			if (input_options[6]=='Direct'): Theta_cm=utilities.get_number_from_pdf_2(PDF[1])
			if (input_options[6]=='Compound'): Theta_cm=utilities.get_number_from_pdf_2(PDF[2])


		if (input_options[11]=='yes'): #Uniform energy distribution
			spread = float(input_options[10]*input_options[8]/100)
			E = np.random.uniform(input_options[8]-spread,input_options[8]+spread)

		if (input_options[12]=='yes'): #Gaussian energy distribution
			FWHM = float(input_options[10]*input_options[8]/100)
			sigma = FWHM/2.355
			E = np.random.normal(input_options[8], sigma)


		Run_kinematics = kinematics.kin_calculator(Theta_cm,E,kinematics_parameters)

		try:  a = Run_kinematics[7]
		except: continue
		Energy_r = Run_kinematics[7]		# New energy of the recoils
		Angle_r = Run_kinematics[5]		# New angle theta of the recoils
		Run_Angle_Change_r = kinematics.change_angle(Angle_r,Phi_cm,1.0,0.0,0.0)
		cosx_r = Run_Angle_Change_r[0]		# New x-cosines of the recoils
		cosy_r = Run_Angle_Change_r[1]		# New y-cosines of the recoils
		cosz_r = Run_Angle_Change_r[2]		# New z-cosines of the recoils
		outR.write("\r\n%i    " %int(l+1) + "%i   " %int(kinematics_parameters[10])  + "{:.7E}  ".format(Energy_r*1E6) + "{:7E}  ".format(float(0.0)) + "{:4E}  ".format(float(0.0)) + "{:4E}  ".format(float(0.0)) + "{:7E}  ".format(cosx_r) + "{:7E}  ".format(cosy_r) + "{:7E}".format(cosz_r))


		Energy_e = Run_kinematics[3]
		Angle_e = Run_kinematics[1]
		Run_Angle_Change_e = kinematics.change_angle(Angle_e,Phi_cm+math.pi,1.0,0.0,0.0)
		cosx_e = Run_Angle_Change_e[0]
		cosy_e = Run_Angle_Change_e[1]
		cosz_e = Run_Angle_Change_e[2]
		outE.write("\r\n%i    " %int(l+1) + "%i   " %int(kinematics_parameters[9]) + "{:.7E}  ".format(Energy_e*1E6) + "{:7E}  ".format(float(0.0)) + "{:4E}  ".format(float(0.0)) + "{:4E}  ".format(float(0.0)) + "{:7E}  ".format(cosx_e) + "{:7E}  ".format(cosy_e) + "{:7E}".format(cosz_e))


		Angle_r_deg = math.fabs(float(Angle_r)*57.295779513)
		Angle_e_deg = math.fabs(float(Angle_e)*57.295779513)
		Theta_cm_r = 180 - Theta_cm*57.2958
		Theta_cm_e = Theta_cm*57.2958
		Angle_r_SRIM = math.acos(cosx_r)*57.295779513
		Angle_e_SRIM = math.acos(cosx_e)*57.295779513

		px = ( np.power(np.arccos(cosx_r),2) - np.power(np.arccos(cosy_r),2) ) /math.pi  +  math.pi/4
		theta = np.arccos(cosz_r)
		if (theta < math.pi/2):
			py = math.sqrt ( math.fabs ( math.pow(math.acos(cosx_r),2) - math.pow(px,2) )  )
		else:
			py = - math.sqrt ( math.fabs ( math.pow(math.acos(cosx_r),2) - math.pow(px,2) )  )


		recoil_file.write("   %i      "%int(l+1) + "   %.6f   "%Run_kinematics[9]  + "   %.2f      " %Energy_r + "%.2f      " %Theta_cm_r + "     %.3f        " %Angle_r_deg + "    %.3f    " %Angle_r_SRIM +  "    %.3f    " %E +  "    %.5f    " %px +  "    %.5f    \n" %py)
		ejectile_file.write("   %i      "%int(l+1) + "   %.6f   "%Run_kinematics[8] + "   %.2f      " %Energy_e + "%.2f      " %Theta_cm_e + "     %.3f        " %Angle_e_deg + "    %.3f    \n" %Angle_e_SRIM)


	recoil_file.close()
	ejectile_file.close()

	outR.close()
	outE.close()



#============================================================================#
#            Create TRIM.dat using a TRANSMIT.txt file
#============================================================================#

if (input_options[0]=='yes'):

	for l in xrange(0,NumberOfParticles-1,1):

		progress=100*float(l)/float(NumberOfParticles)
		sys.stdout.write('\rCalculate new angles and energies...... {} %'.format(round(progress,1)))


		Phi_cm = np.random.uniform(0,2*math.pi)


		if (input_options[2]=='yes'): 	#Uniform angular distribution
			Theta_cm = np.random.uniform(0,math.pi)


		if (input_options[3]=='yes'):   #Talys angular distribution
			if (input_options[6]=='Total'): Theta_cm=utilities.get_number_from_pdf_2(PDF[0])
			if (input_options[6]=='Direct'): Theta_cm=utilities.get_number_from_pdf_2(PDF[1])
			if (input_options[6]=='Compound'): Theta_cm=utilities.get_number_from_pdf_2(PDF[2])


		Run_kinematics = kinematics.kin_calculator(Theta_cm,E[l]*1E-6,kinematics_parameters)

		if (Run_kinematics==0):
			NumberOfRejectedIons +=1
			continue


		Energy_r = Run_kinematics[7]
		Angle_r = Run_kinematics[5]
		Run_Angle_Change_r = kinematics.change_angle(Angle_r,Phi_cm,COSX[l],COSY[l],COSZ[l])
		cosx_r = Run_Angle_Change_r[0]
		cosy_r = Run_Angle_Change_r[1]
		cosz_r = Run_Angle_Change_r[2]
		outR.write("\r\n%i    " %int(l+1) + "%i   " %int(kinematics_parameters[10]) + "{:.7E}  ".format(Energy_r*1E6) + "{:7E}  ".format(float(0.0)) + "{:4E}  ".format(Y[l]) + "{:4E}  ".format(Z[l]) + "{:7E}  ".format(cosx_r) + "{:7E}  ".format(cosy_r) + "{:7E}".format(cosz_r))

		Energy_e = Run_kinematics[3]
		Angle_e = Run_kinematics[1]
		Run_Angle_Change_e = kinematics.change_angle(Angle_e,Phi_cm+math.pi,COSX[l],COSY[l],COSZ[l])
		cosx_e = Run_Angle_Change_e[0]
		cosy_e = Run_Angle_Change_e[1]
		cosz_e = Run_Angle_Change_e[2]
		outE.write("\r\n%i    " %int(l+1) + "%i   " %int(kinematics_parameters[9]) + "{:.7E}  ".format(Energy_e*1E6) + "{:7E}  ".format(float(0.0)) + "{:4E}  ".format(Y[l]) + "{:4E}  ".format(Z[l]) + "{:7E}  ".format(cosx_e) + "{:7E}  ".format(cosy_e) + "{:7E}".format(cosz_e))


		Angle_r_deg = math.fabs(float(Angle_r)*57.295779513)
		Angle_e_deg = math.fabs(float(Angle_e)*57.295779513)
		Theta_cm_r = 180 - Theta_cm*57.2958
		Theta_cm_e = Theta_cm*57.2958
		Angle_r_SRIM = math.acos(cosx_r)*57.295779513
		Angle_e_SRIM = math.acos(cosx_e)*57.295779513

		recoil_file.write("   %i      "%int(l+1) + "   %.2f      " %Energy_r + "%.2f      " %Theta_cm_r + "     %.3f        " %Angle_r_deg + "    %.3f    \n" %Angle_r_SRIM )
		ejectile_file.write("   %i      "%int(l+1) + "   %.2f      " %Energy_e + "%.2f      " %Theta_cm_e + "     %.3f        " %Angle_e_deg + "    %.3f    \n" %Angle_e_SRIM)


	recoil_file.close()
	ejectile_file.close()

	outE.close()
	outR.close()




if os.path.exists("{}/junk_file".format(output_file)): os.remove("{}/junk_file".format(output_file))
print ("\n\n   * Calculation was succesfull *\n")





note=""
if (input_options[0]=='yes' and NumberOfRejectedIons > 0):
	time.sleep(1)
	note = "\n\n**** NOTE *************************************************\n{}".format(NumberOfRejectedIons) + " out of {}".format(NumberOfParticles)+" ions didn't have sufficient energy\nfor this reaction and they were rejected!\n***********************************************************\n"
	print note

time.sleep(1)
if(W1==True):print "\n**WARNING**: \nRecoils are not charged particles! No TRIM file was created for them!\n"
if(W2==True):print "\n**WARNING**: \nEjectiles are not charged particles! No TRIM file was created for them!\n"


utilities.make_report(input_file,output_file,note)
