
import numpy as np
import math
import pylab as pl
import sys
import os
import glob
import time
sys.path.append(os.getcwd() + '/Modules/')
import kinematics
import utilities



input_file = sys.argv[-1]
utilities.check_typos_input_file(input_file)
input_options=utilities.check_input_options_ToF(input_file)
utilities.create_output_file()
output_file = max(glob.iglob('OUTPUTS/*'), key=os.path.getctime)
kinematics_parameters = utilities.read_input_parameters(input_file)



if (kinematics.kin_calculator(0.0,input_options[0],kinematics_parameters)==0):
	sys.exit("\n**CAUTION: Not enough c.m. energy for this reaction!\n")



output_ascii = open("{}/Kinematics_TOF.txt".format(output_file), 'wb')
head_line = " Theta_lab(deg)  E_lab(MeV)  DE_lab(MeV)   TOF(nsec)   DTOF(nsec)\n"

#========================================================================#
#     		    	    CALCULATION STARTS HERE
#========================================================================#


Angles_deg = [i for i in xrange(0,180,5)]

Angles_rad = np.array(Angles_deg)*(math.pi/180.)

for Ex in input_options[4]:
	kinematics_parameters[5]=float(Ex)
	FWHM = float(input_options[0]*input_options[1]/100)
	sigma = FWHM/2.355
	E_mean = input_options[0]
	E_min = input_options[0]-sigma
	E_max = input_options[0]+sigma
	output_ascii.write("\n ---- Excitation energy = {} MeV ---- \n".format(Ex))
	output_ascii.write(head_line)

	for Theta_cm in Angles_rad:
		Run_kinematics_min = kinematics.kin_calculator(Theta_cm,E_min,kinematics_parameters)
		Run_kinematics_mean = kinematics.kin_calculator(Theta_cm,E_mean,kinematics_parameters)
		Run_kinematics_max = kinematics.kin_calculator(Theta_cm,E_max,kinematics_parameters)

		Energy_ej_min = Run_kinematics_min[3]
		Energy_ej_mean = Run_kinematics_mean[3]
		Energy_ej_max = Run_kinematics_max[3]

		DE = np.fabs(Energy_ej_max-Energy_ej_min)/2.

		TOF_min = 100*input_options[2]/(math.sqrt(2*Energy_ej_min/939.57)*29.9792458)
		TOF_mean = 100*input_options[2]/(math.sqrt(2*Energy_ej_mean/939.57)*29.9792458)
		TOF_max = 100*input_options[2]/(math.sqrt(2*Energy_ej_max/939.57)*29.9792458)


		DTOF = (TOF_min-TOF_max)/2.

		if Run_kinematics_mean[2]<0.: Angle_ej_lab_deg = 180. + Run_kinematics_mean[2]
		else: Angle_ej_lab_deg = Run_kinematics_mean[2]

		output_ascii.write("{:0.2f}		".format(Angle_ej_lab_deg) + "{:0.3f}		".format(Energy_ej_mean) + "{:0.3f}		".format(DE) + "{:0.1f}		".format(TOF_mean) + "{:0.1f}\n".format(DTOF) )


output_ascii.close()

utilities.make_report(input_file,output_file,"")
