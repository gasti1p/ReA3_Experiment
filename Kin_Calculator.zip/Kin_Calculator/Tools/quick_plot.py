import math,sys
import os,glob
import numpy as np
import pylab as pl
from matplotlib.colors import LogNorm




list_of_outputs = os.listdir("../OUTPUTS")
options = [i for i in xrange(0,len(list_of_outputs),1)]

print "\n\n\nCurrent files in the 'OUTPUTS' directory:"
for i in xrange(1,len(list_of_outputs)):
	print (  "{}.".format(options[i]) + "  {}".format(list_of_outputs[i])   )

directory_index= int( raw_input('\nChoose your output file from the list above. Type number:\n')  )

directory=list_of_outputs[directory_index]


ejectiles_file = "../OUTPUTS/{}/Ejectile_characteristics.txt".format(directory)
recoils_file = "../OUTPUTS/{}/Recoil_characteristics.txt".format(directory)


print "\n\nPlot data for: \n1. Recoils \n2. Ejectiles"
product_index= int( raw_input('\nChoose one of the above. Type number:\n')  )

Ee,Er,E = [],[],[]
Thetacme,Thetacmr,Thetacm = [],[],[]
Thetalabe,Thetalabr,Thetalab = [],[],[]
Thetasrime,Thetasrimr,Thetasrim = [],[],[]
plot_options = []	

NumberOfParticles=0

if (product_index==2):
	with open (ejectiles_file) as textFile:
		for line in textFile:
			if not line.startswith(' Ion'):
				E.append(float(line.split()[1]))
				Thetacm.append(float(line.split()[2]))
				Thetalab.append(float(line.split()[3]))			
				Thetasrim.append(float(line.split()[4]))
				NumberOfParticles +=1
			else: 
				plot_options.append(line.split())
			
if (product_index==1):
	with open (recoils_file) as textFile2:
		for line in textFile2:
			if not line.startswith(' Ion'):
				E.append(float(line.split()[1]))
				Thetacm.append(float(line.split()[2]))
				Thetalab.append(float(line.split()[3]))			
				Thetasrim.append(float(line.split()[4]))
				NumberOfParticles +=1
			else: 
				plot_options.append(line.split())


plot_options_num = [i for i in xrange(0,len(plot_options[0]),1)]

print "\n\nAvailable quantities for histograms:"
for i in xrange(1,len(plot_options[0])):
	print (  "{}.".format(plot_options_num[i]) + "  {}".format(plot_options[0][i])   )
print (  "5." + "  Theta-lab_vs_Energy (2D)"   )

quantity_index= int( raw_input('\nChoose one of the above. Type number:\n')  )

if (quantity_index==1):
	x = E
	mean = np.mean(E)
	Max = np.max(E)
	Min = np.min(E)

if (quantity_index==2):
	x = Thetacm
	mean = np.mean(Thetacm)
	Max = np.max(Thetacm)
	Min = np.min(Thetacm)

if (quantity_index==3):
	x = Thetalab
	mean = np.mean(Thetalab)
	Max = np.max(Thetalab)
	Min = np.min(Thetalab)

if (quantity_index==4):
	x = Thetasrim
	mean = np.mean(Thetasrim)
	Max = np.max(Thetasrim)
	Min = np.min(Thetasrim)

if (quantity_index==5):
	x = Thetalab
	y = E
	meanE = np.mean(E)
	MaxE = np.max(E)
	MinE = np.min(E)
	meanT = np.mean(Thetasrim)
	MaxT = np.max(Thetasrim)
	MinT = np.min(Thetasrim)


#fig = pl.figure(figsize=(13,8))

if not (quantity_index==5):
	step = float ( (Max-Min)/150 )
	bins= np.arange(Min-1, Max+1, step)
	pl.hist(x,bins,facecolor='blue',histtype='stepfilled',label="Data1")
	pl.yscale('log',nonposy='clip')
	pl.title('{}'.format( plot_options[0][quantity_index] ) )
	pl.axis([Min-1, Max+1,1,NumberOfParticles+1000])
	pl.xticks(np.arange(Min-1, Max+1, 1.0))
	#pl.yticks(np.arange(1, 1e+5, 1000))
	pl.xlabel('{}'.format(plot_options[0][quantity_index])  )
	pl.ylabel('Particles')
	pl.legend(loc='upper right',fontsize=11,frameon='No')

else:
	stepx = float ( (MaxT-MinT)/150 )	
	stepy = float ( (MaxE-MinE)/150 )
	binsx= np.arange(MinT-1, MaxT+1, stepx)
	binsy= np.arange(MinE-1, MaxE+1, stepy)
	pl.hist2d(x,y,bins=(binsx,binsy),norm=LogNorm())
	pl.colorbar()
		



#pl.savefig('Energy2.jpeg')
pl.show()



