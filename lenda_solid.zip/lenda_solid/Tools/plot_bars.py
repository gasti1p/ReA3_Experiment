import math,sys
import os,glob
import numpy as np
import pylab as pl
from matplotlib.colors import LogNorm




list_of_outputs = os.listdir("../OUTPUT")
options = [i for i in xrange(1,len(list_of_outputs)+1,1)]

print "\n\n\nCurrent files in the 'OUTPUTS' directory:"
for i in xrange(0,len(list_of_outputs)):
	print (  "{}.".format(options[i]) + "  {}".format(list_of_outputs[i])   )
print "\n"


BarNames = [ list_of_outputs[i][:4] for i in xrange(0,len(list_of_outputs),1) ]


options_line = file( '../OUTPUT/{}'.format(list_of_outputs[0]) , 'r' ).readlines()[0]
plot_options = options_line.split()



print "\n\nAvailable quantities for histograms:"
for i in xrange(1,len(plot_options)):
	print (  "{}.".format(i) + "  {}".format(plot_options[i])   )

quantity_index= int( raw_input('\nChoose one of the above. Type number:\n')  )



pl.figure(figsize=(18,9))
Detected_neutrons = []

for i in xrange(0,len(list_of_outputs),1):
	plot_index = int ("24{}".format(i+1))
	x = []
	X = 0.0
	opened_file = "../OUTPUT/{}".format(list_of_outputs[i]) 
	f = open(opened_file,'r')
	for line in f:
		if not line.startswith('#'):
			x.append(float( line.split()[quantity_index-1] ) )

	f.close()
	
	X = np.array(x)
	HighE = len( X[np.where(X > 3.0)] )
	LowE = len( X[np.where(X < 3.0)] )
	TotInt = len(X)


	pl.subplot(plot_index)

	if (len(X) != 0):
		Detected_neutrons.append(len(X))
		mean = np.mean(X)
		Max = np.max(X)
		Min = np.min(X)
		step = float ( (Max-Min)/150 )
		bins= np.arange(Min-1, Max+1, step)
		LabeL = "Data"

		if (quantity_index == 1):
			LabeL = "Total counts = {}\n".format(TotInt) + "HE>3MeV= {}\n".format(HighE) + "LE<3MeV= {}".format(LowE) 
			pl.xlabel('Neutron energy (MeV)')
		elif (quantity_index == 2):
			LabeL = "Total counts = {}".format(TotInt)
			pl.xlabel('Theta-lab (deg)')
		elif (quantity_index == 3):
			LabeL = "Total counts = {}".format(TotInt)
			pl.xlabel('Position in lenda bar (cm)')

		pl.hist(X,bins,facecolor='blue',histtype='stepfilled',label=LabeL )


		pl.legend(loc='best',fontsize=11,frameon=True,title='{}'.format(BarNames[i]) )


	else: 	Detected_neutrons.append(0.0)

	#pl.yscale('log',nonposy='clip')
	#pl.axis([Min-1, Max+1,1,2000])
	#pl.xticks(np.arange(Min-1, Max+1, 1.0))
	#pl.yticks(np.arange(1, 1e+5, 1000))
	#pl.xlabel('Neutron energy (MeV)')
	#pl.ylabel('Particles')
	#pl.savefig('Plot{}.jpeg'.format(plot_index))


pl.subplot(plot_index+1)
bar=[i for i in xrange(0,len(Detected_neutrons),1)]
pl.bar(bar,Detected_neutrons,align='center', color='r', alpha=0.9, label='Detected neutrons')
bars = np.arange(len(BarNames))
pl.xticks(bars, BarNames)
pl.legend(loc='best',fontsize=11,frameon='No')



pl.subplots_adjust(top=0.92, bottom=0.08, left=0.03, right=0.98, hspace=0.25, wspace=0.15)

pl.show()



