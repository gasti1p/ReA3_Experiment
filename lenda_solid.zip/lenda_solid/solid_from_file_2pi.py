import math,sys
import numpy as np
import pylab as pl
from matplotlib.colors import LogNorm


file_name = sys.argv[-1]


D=19.5
#D=20.5
offset=0.0

NumBars=7
Pipe=6.35
W=4.5
H=2.5
L1=33.8+offset
L2=40.3+offset
LD1 = L1 + H/2
LD2 = L2 + H/2

BarSet,NewBarSet=[],[]
a=[0,0,0,0]
b=[0,0,0,0]
c=[0,0,0,0]
Bar=NewBar=[a,b,c]



j11=math.atan(W/(2*L1))
j21=math.atan(W/(2*(L1+H)))

j12=math.atan(W/(2*L2))
j22=math.atan(W/(2*(L2+H)))

theta = math.atan( Pipe/(2*L1) )

print "\n\n"
for i in xrange(0,NumBars,1):
	if (i % 2 == 0 or i==0):
		Bar[0][0] = theta
		Bar[0][1] = theta+(j11-j21)
		Bar[0][2] = theta+j11+j21
		Bar[0][3] = theta+2*j11

		Bar[1][0] = math.sqrt(math.pow(W/2,2)  +  math.pow(L1,2)  )
		Bar[1][1] = math.sqrt(math.pow(W/2,2)  +  math.pow(L1+H,2)  )
		Bar[1][2] = Bar[1][1]
		Bar[1][3] = Bar[1][0]

		Bar[2][0] = theta+j11
		Bar[2][1] = theta+j11
		Bar[2][2] = theta+j11
		Bar[2][3] = theta+j11

		BarI=np.array(Bar)
		theta = theta+2*j11
		BarSet.append(BarI)
		print ( "BarId: {}  -- ".format(i+1)  +  " Angle (deg):  {}".format(Bar[2][0]*57.2958) )

	else:
		Bar[0][0] = theta
		Bar[0][1] = theta+(j12-j22)
		Bar[0][2] = theta+j12+j22
		Bar[0][3] = theta+2*j12

		Bar[1][0] = math.sqrt(math.pow(W/2,2)  +  math.pow(L2,2)  )
		Bar[1][1] = math.sqrt(math.pow(W/2,2)  +  math.pow(L2+H,2)  )
		Bar[1][2] = Bar[1][1]
		Bar[1][3] = Bar[1][0]

		Bar[2][0] = theta+j12
		Bar[2][1] = theta+j12
		Bar[2][2] = theta+j12
		Bar[2][3] = theta+j12

		BarI=np.array(Bar)
		theta = theta+2*j12
		BarSet.append(BarI)
		print ( "BarId: {}  -- ".format(i+1)  +  " Angle (deg):  {}".format(Bar[2][0]*57.2958) )

Bars=np.array(BarSet)


for i in xrange(0,NumBars,1):
		NewBar[2][0] = math.pi - Bars[i][0][0]
		NewBar[2][1] = math.pi - Bars[i][0][1]
		NewBar[2][2] = math.pi - Bars[i][0][2]
		NewBar[2][3] = math.pi - Bars[i][0][3]

		NewBar[1][0] = math.sqrt( math.pow(Bars[i][1][0],2)  +  math.pow(D,2) - 2*Bars[i][1][0]*D*math.cos(NewBar[2][0])  )
		NewBar[1][1] = math.sqrt( math.pow(Bars[i][1][1],2)  +  math.pow(D,2) - 2*Bars[i][1][1]*D*math.cos(NewBar[2][1])  )
		NewBar[1][2] = math.sqrt( math.pow(Bars[i][1][2],2)  +  math.pow(D,2) - 2*Bars[i][1][2]*D*math.cos(NewBar[2][2])  )
		NewBar[1][3] = math.sqrt( math.pow(Bars[i][1][3],2)  +  math.pow(D,2) - 2*Bars[i][1][3]*D*math.cos(NewBar[2][3])  )

		NewBar[0][0] = math.asin(  Bars[i][1][0]*math.sin(NewBar[2][0])/NewBar[1][0]  )
		NewBar[0][1] = math.asin(  Bars[i][1][1]*math.sin(NewBar[2][1])/NewBar[1][1]  )
		NewBar[0][2] = math.asin(  Bars[i][1][2]*math.sin(NewBar[2][2])/NewBar[1][2]  )
		NewBar[0][3] = math.asin(  Bars[i][1][3]*math.sin(NewBar[2][3])/NewBar[1][3]  )

		NewBarO=np.array(NewBar)
		NewBarSet.append(NewBarO)

NewBars=np.array(NewBarSet)



Front_bar_x =[]
Front_bar_y =[]

Back_bar_x =[]
Back_bar_y =[]

x_emit = []
y_emit = []

x_detected = []
y_detected = []

x_frame = []
y_frame = []

x_plane_emit = []
y_plane_emit = []

Energy = []

BarId = []

Theta_dir_h = []

last_line = file(file_name, "r").readlines()[-1]
NumParts = float(last_line.split()[0])
prt=0.0;


print ""
sys.stdout.write('Calculate solid angle coverage...... ')
sys.stdout.flush()

with open (file_name) as f:
   for line in f:
     if not 'IonNumber' in line:

	ion_num = float(line.split()[0])
	if ion_num==10000: break
	progress=100*ion_num/NumParts
	sys.stdout.write('\rCalculate solid angle coverage...... {} %'.format(round(progress,1)))

	Energy_emit = float(line.split()[1])
	Theta_emit = float(line.split()[3])*0.0174533
	Phi_emit = np.random.uniform( 0 , math.pi/2)


	Theta_dir = (math.sin(Theta_emit)*math.sin(Phi_emit))/math.sqrt(  1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2))
	D_emit_at100cm = math.sqrt( math.pow(100,2) / (1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2)))
	emit_height_at100cm = D_emit_at100cm*math.sin(Theta_emit)*math.cos(Phi_emit)
	emit_offset_at100cm = D_emit_at100cm*math.sin(Theta_emit)*math.sin(Phi_emit)


	Theta_dir_h.append(Theta_dir*57.2958) #histo for emit angles

	x_plane_emit_i = math.fabs( L2*math.sin(Theta_dir)   )
	y_plane_emit_i = math.fabs( L2*math.cos(Theta_dir)   )

	x_plane_emit.append( x_plane_emit_i )
	y_plane_emit.append( y_plane_emit_i )

	x_emit.append( emit_offset_at100cm )
	y_emit.append( emit_height_at100cm )



	for i in xrange(0,NumBars,1):

		Theta_min = min(NewBars[i][0])
		Theta_max = max(NewBars[i][0])
		Theta_mean = np.mean(NewBars[i][0])
		Theta_ksi = math.fabs( Theta_mean - Theta_dir )

		Theta_mean_init = np.mean(Bars[i][0])
		Theta_proj = math.fabs( math.pi - Theta_mean_init )

		L1_bar = math.sqrt( math.pow(D,2) + math.pow(LD1,2) - 2*D*LD1*math.cos(Theta_proj) )
		L2_bar = math.sqrt( math.pow(D,2) + math.pow(LD2,2) - 2*D*LD2*math.cos(Theta_proj) )

		ID = i+1

		if (Theta_dir > Theta_min and Theta_dir < Theta_max):

			#if (i % 2 == 0 or i==0): R = NewBars[i][0][0]/math.cos(Theta_ksi)
			#else: R = NewBars[i][0][0]/math.cos(Theta_ksi)
			R = NewBars[i][1][0]/math.cos(Theta_ksi)

			D =  R / math.sqrt( 1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2)  )
			height_i = D*math.sin(Theta_emit)*math.cos(Phi_emit)
			offset_i = D*math.sin(Theta_emit)*math.sin(Phi_emit)


			D_frame = R/math.cos(Theta_ksi)


			x_frame_i = math.fabs(  D_frame*math.sin(Theta_dir)   )
			y_frame_i = math.fabs(  D_frame*math.cos(Theta_dir)   )


			if (height_i <= 15 and height_i >= -15 ):
			   	if (ID==6 and Theta_dir*57.2958 > 30.43 ): continue
				BarId.append(ID)
				x_detected.append(offset_i)
				y_detected.append(height_i)
				Energy.append(Energy_emit)

				if (i % 2 == 0 or i==0):
					Front_bar_x.append(offset_i)
					Front_bar_y.append(height_i)
				else:
					Back_bar_x.append(offset_i)
					Back_bar_y.append(height_i)


				x_frame.append(x_frame_i)
				y_frame.append(y_frame_i)

				prt+=1
				break;


print ("\nDetected particles:  {}".format(prt) + "  out of  {}".format(NumParts))

print "\n"
print "DIANGNOSTICS\n"
print "BarId	MinAngle(deg)	  MeanAngle(deg)     MaxAngle(deg)"
for i in xrange(0,NumBars,1):
	print ( " {}	".format(i+1)  +  "{}".format(min(NewBars[i][0])*57.2958) + "	{}".format(np.mean(NewBars[i][0])*57.2958)  + "	{}".format(max(NewBars[i][0])*57.2958) )


#pl.hist2d(x_n,y_n,norm=LogNorm())
bar_bins=[0.5,1.5,2.5,3.5,4.5,5.5,6.5]
energy_bins = [float(x/100.0) for x in xrange(1,900,1)]
#pl.hist2d(BarId,Energy,bins=(bar_bins,energy_bins), norm=LogNorm())

#pl.scatter(x_emit,y_emit)
#pl.scatter(x_detected,y_detected)


#pl.plot(Back_bar_x,Back_bar_y,'bo')
#pl.plot(Front_bar_x,Front_bar_y,'ro')

#pl.scatter(x_frame,y_frame)
#pl.scatter(x_plane_emit,y_plane_emit)

pl.hist(BarId,bins=[0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5])
#bins=[i for i in range(0,40)]
#pl.hist(Theta_dir_h,bins=[i for i in range(0,40)])

#pl.colorbar()

#pl.axis([-0.5, 5.5,1,prt])
#pl.xlim(0,100)
#pl.ylim(0,10000)

pl.show()
