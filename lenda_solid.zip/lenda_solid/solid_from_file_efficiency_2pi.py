import math,sys,os,shutil
import numpy as np
import pylab as pl
from matplotlib.colors import LogNorm


file_name = sys.argv[-1]


#D=19.5
D=19.5
offset=0.0
NumBars=7


BarParameters=[]
BarsInfo = []
BarNamesL = []
BarNamesR = []
mapfile = open('BarsEfficiency/MapFile.txt','r')


for line in mapfile:
	barnameR = line.split()[2]
	barnameL = line.split()[2]
	parametersA = file('BarsEfficiency/{}_fit.txt'.format(barnameR), "r").readlines()[0]
	parametersB = file('BarsEfficiency/{}_fit.txt'.format(barnameR), "r").readlines()[1]
	BarNamesL.append(barnameL)
	BarNamesR.append(barnameR)

	parA = [ float(parametersA.split()[0]),
		 float(parametersA.split()[1]),
		 float(parametersA.split()[2]),
		 float(parametersA.split()[3]),
		 float(parametersA.split()[4]),
		 float(parametersA.split()[5]),
		 float(parametersA.split()[6]) ]

	parB = [ float(parametersB.split()[0]),
		 float(parametersB.split()[1]),
		 float(parametersB.split()[2]),
		 float(parametersB.split()[3]),
		 float(parametersB.split()[4]),
		 float(parametersB.split()[5]),
		 float(parametersB.split()[6]) ]


	BarParameters = [ parA, parB]
	BarsInfo.append(BarParameters)

mapfile.close()


Pipe=6.35
W=4.5
H=2.5
L1=33.75+offset
L2=40.25+offset
LD1 = L1 + H/2
LD2 = L2 + H/2

BarSet,NewBarSet=[],[]
a=[0,0,0,0]
b=[0,0,0,0]
c=[0,0,0,0]
Bar=NewBar=[a,b,c]



j11=math.atan(W/(2*L1))
j21=math.atan(W/(2*(L1+H)))

j12=math.atan(W/(2*L2))
j22=math.atan(W/(2*(L2+H)))

theta = math.atan( Pipe/(2*L1) )

print "\n"
print "      ***************      "
print "      *    REPORT   *      "
print "      ***************      "
print "\n"
for i in xrange(0,NumBars,1):
	if (i % 2 == 0 or i==0):
		Bar[0][0] = theta
		Bar[0][1] = theta+(j11-j21)
		Bar[0][2] = theta+j11+j21
		Bar[0][3] = theta+2*j11

		Bar[1][0] = math.sqrt(math.pow(W/2,2)  +  math.pow(L1,2)  )
		Bar[1][1] = math.sqrt(math.pow(W/2,2)  +  math.pow(L1+H,2)  )
		Bar[1][2] = Bar[1][1]
		Bar[1][3] = Bar[1][0]

		Bar[2][0] = theta+j11
		Bar[2][1] = theta+j11
		Bar[2][2] = theta+j11
		Bar[2][3] = theta+j11

		BarI=np.array(Bar)
		theta = theta+2*j11
		BarSet.append(BarI)
		print ( "BarId: {}  -- ".format(i+1)  +  " Angle (deg):  {}".format(round(Bar[2][0]*57.2958,2)) )

	else:
		Bar[0][0] = theta
		Bar[0][1] = theta+(j12-j22)
		Bar[0][2] = theta+j12+j22
		Bar[0][3] = theta+2*j12

		Bar[1][0] = math.sqrt(math.pow(W/2,2)  +  math.pow(L2,2)  )
		Bar[1][1] = math.sqrt(math.pow(W/2,2)  +  math.pow(L2+H,2)  )
		Bar[1][2] = Bar[1][1]
		Bar[1][3] = Bar[1][0]

		Bar[2][0] = theta+j12
		Bar[2][1] = theta+j12
		Bar[2][2] = theta+j12
		Bar[2][3] = theta+j12

		BarI=np.array(Bar)
		theta = theta+2*j12
		BarSet.append(BarI)
		print ( "BarId: {}  -- ".format(i+1)  +  " Angle (deg):  {}".format(round(Bar[2][0]*57.2958,2)) )

Bars=np.array(BarSet)


for i in xrange(0,NumBars,1):
		NewBar[2][0] = math.pi - Bars[i][0][0]
		NewBar[2][1] = math.pi - Bars[i][0][1]
		NewBar[2][2] = math.pi - Bars[i][0][2]
		NewBar[2][3] = math.pi - Bars[i][0][3]

		NewBar[1][0] = math.sqrt( math.pow(Bars[i][1][0],2)  +  math.pow(D,2) - 2*Bars[i][1][0]*D*math.cos(NewBar[2][0])  )
		NewBar[1][1] = math.sqrt( math.pow(Bars[i][1][1],2)  +  math.pow(D,2) - 2*Bars[i][1][1]*D*math.cos(NewBar[2][1])  )
		NewBar[1][2] = math.sqrt( math.pow(Bars[i][1][2],2)  +  math.pow(D,2) - 2*Bars[i][1][2]*D*math.cos(NewBar[2][2])  )
		NewBar[1][3] = math.sqrt( math.pow(Bars[i][1][3],2)  +  math.pow(D,2) - 2*Bars[i][1][3]*D*math.cos(NewBar[2][3])  )

		NewBar[0][0] = math.asin(  Bars[i][1][0]*math.sin(NewBar[2][0])/NewBar[1][0]  )
		NewBar[0][1] = math.asin(  Bars[i][1][1]*math.sin(NewBar[2][1])/NewBar[1][1]  )
		NewBar[0][2] = math.asin(  Bars[i][1][2]*math.sin(NewBar[2][2])/NewBar[1][2]  )
		NewBar[0][3] = math.asin(  Bars[i][1][3]*math.sin(NewBar[2][3])/NewBar[1][3]  )

		NewBarO=np.array(NewBar)
		NewBarSet.append(NewBarO)

NewBars=np.array(NewBarSet)



Front_bar_x =[]
Front_bar_y =[]

Back_bar_x =[]
Back_bar_y =[]

x_emit = []
y_emit = []

x_detected = []
y_detected = []

x_frame = []
y_frame = []

x_plane_emit = []
y_plane_emit = []

Energy = []

BarId = []

Theta_dir_h = []

last_line = file(file_name, "r").readlines()[-1]
NumParts = int(last_line.split()[0])

prt1=prt2=prt3=prt4=prt5=prt6=prt7=0.0
prt=prt1t=prt2t=prt3t=prt4t=prt5t=prt6t=prt7t=0





if os.path.exists('OUTPUT'):
	shutil.rmtree('OUTPUT')
   	os.makedirs('OUTPUT')
else: os.makedirs('OUTPUT')


for i in xrange(0,NumBars,1):
	f = open('OUTPUT/{}_neutrons.txt'.format(BarNamesR[i]),'a')
	f.write( "# E_neutron(MeV)    Theta_lab(deg)    Position_in_bar(cm)\n" )
	f.close()


print ""
sys.stdout.write('Calculate solid angle coverage...... ')
sys.stdout.flush()



with open (file_name) as f:
   next(f)
   for line in f:
	ion_num = float(line.split()[0])
	#if ion_num==1000: break
	progress=100*ion_num/NumParts
	sys.stdout.write('\rCalculate solid angle coverage...... {} %'.format(round(progress,1)))

	Energy_emit = float(line.split()[1])
	Theta_emit = float(line.split()[3])*0.0174533
	#try: Phi_emit = float(line.split()[5])
	#except: Phi_emit = np.random.uniform( 0 , math.pi)
	Phi_emit = np.random.uniform( 0 , math.pi)


	Theta_dir = (math.sin(Theta_emit)*math.sin(Phi_emit))/math.sqrt(  1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2))
	D_emit_at100cm = math.sqrt( math.pow(100,2) / (1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2)))
	emit_height_at100cm = D_emit_at100cm*math.sin(Theta_emit)*math.cos(Phi_emit)
	emit_offset_at100cm = D_emit_at100cm*math.sin(Theta_emit)*math.sin(Phi_emit)


	Theta_dir_h.append(Theta_dir*57.2958) #histo for emit angles

	x_plane_emit_i = math.fabs( L2*math.sin(Theta_dir)   )
	y_plane_emit_i = math.fabs( L2*math.cos(Theta_dir)   )

	x_plane_emit.append( x_plane_emit_i )
	y_plane_emit.append( y_plane_emit_i )

	x_emit.append( emit_offset_at100cm )
	y_emit.append( emit_height_at100cm )



	for i in xrange(0,NumBars,1):

		Theta_min = min(NewBars[i][0])
		Theta_max = max(NewBars[i][0])
		Theta_mean = np.mean(NewBars[i][0])
		Theta_ksi = math.fabs( Theta_mean - Theta_dir )

		Theta_mean_init = np.mean(Bars[i][0])
		Theta_proj = math.fabs( math.pi - Theta_mean_init )

		L1_bar = math.sqrt( math.pow(D,2) + math.pow(LD1,2) - 2*D*LD1*math.cos(Theta_proj) )
		L2_bar = math.sqrt( math.pow(D,2) + math.pow(LD2,2) - 2*D*LD2*math.cos(Theta_proj) )

		ID = i+1

		if (Theta_dir > Theta_min and Theta_dir < Theta_max):

			#if (i % 2 == 0 or i==0): R = NewBars[i][0][0]/math.cos(Theta_ksi)
			#else: R = NewBars[i][0][0]/math.cos(Theta_ksi)
			R = NewBars[i][1][0]/math.cos(Theta_ksi)

			D =  R / math.sqrt( 1 - math.pow(math.sin(Theta_emit),2)*math.pow(math.cos(Phi_emit),2)  )
			height_i = D*math.sin(Theta_emit)*math.cos(Phi_emit)
			offset_i = D*math.sin(Theta_emit)*math.sin(Phi_emit)


			D_frame = R/math.cos(Theta_ksi)


			x_frame_i = math.fabs(  D_frame*math.sin(Theta_dir)   )
			y_frame_i = math.fabs(  D_frame*math.cos(Theta_dir)   )


			#if ( math.fabs(height_i) <= 15.0 ):
			if ( height_i < 15.0 and height_i > -15.0 ):

			   	#if (ID==4 and Theta_dir*57.2958 > 21.1 ): continue
			   	if (ID==6 and Theta_dir*57.2958 > 30.2 ): continue


				if (Energy_emit < 1.9):
					Efficiency = BarsInfo[i][0][0] + BarsInfo[i][0][1]*Energy_emit + BarsInfo[i][0][2]*math.pow(Energy_emit,2) + BarsInfo[i][0][3]*math.pow(Energy_emit,3) + BarsInfo[i][0][4]*math.pow(Energy_emit,4) + BarsInfo[i][0][5]*math.pow(Energy_emit,5) + BarsInfo[i][0][6]*math.pow(Energy_emit,6)



				elif (Energy_emit >= 1.9):
					Efficiency = BarsInfo[i][1][0] + BarsInfo[i][1][1]*Energy_emit + BarsInfo[i][1][2]*math.pow(Energy_emit,2) + BarsInfo[i][1][3]*math.pow(Energy_emit,3) + BarsInfo[i][1][4]*math.pow(Energy_emit,4) + BarsInfo[i][1][5]*math.pow(Energy_emit,5) + BarsInfo[i][1][6]*math.pow(Energy_emit,6)



				elif (Efficiency<0): Efficiency=0.0

				#print "       {}".format(Efficiency) + "    {}".format(Energy_emit)


				f = open('OUTPUT/{}_neutrons.txt'.format(BarNamesR[i]),'a')
				f.write( "{}".format(Energy_emit) + "   {}".format(Theta_dir*57.2958) + "   {}\n".format(height_i))
				f.close()

				Efficiency=Efficiency*0.92
				if (ID==1):
					prt1 += 0.90*Efficiency/100
					prt1t += 0.90*1
				if (ID==2):
					prt2 += 0.88*Efficiency/100
					prt2t += 0.88*1
				if (ID==3):
					prt3 += Efficiency/100
					prt3t += 1
				if (ID==4):
					prt4 += Efficiency/100
					prt4t += 1.05
				if (ID==5):
					prt5 += Efficiency/100
					prt5t += 1.05
				if (ID==6):
					prt6 += Efficiency/100
					prt6t += 1.02
				if (ID==7):
					prt7 += Efficiency/100
					prt7t += 1.02

				BarId.append(ID)
				x_detected.append(offset_i)
				y_detected.append(height_i)
				Energy.append(Energy_emit)

				if (i % 2 == 0 or i==0):
					Front_bar_x.append(offset_i)
					Front_bar_y.append(height_i)
				else:
					Back_bar_x.append(offset_i)
					Back_bar_y.append(height_i)


				x_frame.append(x_frame_i)
				y_frame.append(y_frame_i)

				prt+=1
				break;

counts = [prt1,prt2,prt3,prt4,prt5,prt6,prt7]
totcounts = [prt1t,prt2t,prt3t,prt4t,prt5t,prt6t,prt7t]


print ("\n\nParticles that hit LENDA:  {}".format(np.sum(totcounts)) + "  out of  {}".format(NumParts) + "  [{} %] ".format(round(100*float(np.sum(totcounts))/float(NumParts),2))    )
print ("Particles detected:  {}".format( int(np.sum(counts)) ) + "  out of  {}".format(int(np.sum(totcounts))) + " [{} %] ".format(round(100*int(np.sum(counts))/np.sum(totcounts),2))    )


print "\n"
print "DIANGNOSTICS\n"
print "BarId	MinAngle(deg)	  MeanAngle(deg)     MaxAngle(deg)"
for i in xrange(0,NumBars,1):
	print ( " {}	".format(i+1)  +  "{}".format(min(NewBars[i][0])*57.2958) + "	{}".format(np.mean(NewBars[i][0])*57.2958)  + "	{}".format(max(NewBars[i][0])*57.2958) )




print "\n"
print "BarId	BarName    Detected #"
for i in xrange(0,NumBars,1):
	if (totcounts[i]>0):
		print ( " {}".format(i+1) +"        {}".format(BarNamesR[i])  +  "        {}".format(int(counts[i])) + "       out of: {}".format(int(totcounts[i])) +  " [{} %] ".format(round(100*counts[i]/totcounts[i],2))   )



print "\n"
print "      *****************      "
print "      * END OF REPORT *      "
print "      *****************      "
print "\n"




#pl.hist2d(x_n,y_n,norm=LogNorm())
bar_bins=[0.5,1.5,2.5,3.5,4.5,5.5,6.5]
energy_bins = [float(x/100.0) for x in xrange(1,900,1)]
#pl.hist2d(BarId,Energy,bins=(bar_bins,energy_bins), norm=LogNorm())

#pl.scatter(x_emit,y_emit)
#pl.hist2d(x_emit,y_emit,bins=( [ x for x in xrange(1,90,2)] , [ x for x in xrange(-90,90,4)]), norm=LogNorm())
#pl.scatter(x_detected,y_detected)


#pl.plot(Back_bar_x,Back_bar_y,'bo')
#pl.plot(Front_bar_x,Front_bar_y,'ro')

#pl.scatter(x_frame,y_frame)
#pl.scatter(x_plane_emit,y_plane_emit)

pl.hist(BarId,bins=[0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5])
#bins=[i for i in range(0,40)]
#pl.hist(Theta_dir_h,bins=[i for i in range(0,40)])

#pl.colorbar()

#pl.axis([-0.5, 5.5,1,prt])
#pl.xlim(0,100)
#pl.ylim(0,10000)

pl.show()
